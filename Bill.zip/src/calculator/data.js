import { useSelector } from "react-redux"
import { ActionCreator } from "../common/redux/action";
import { store } from "../common/redux/store";

export const PData=()=>{

    const output=useSelector(state=>state.Data);
    let arr=[]
    for(let i in output){
        arr.push(i)
    };

    function entered(){
        let disc=0;
        let recamt=0;
        if(document.getElementById('Discount').value.length!==0){
            if(document.getElementById('Discount').value>100){
                disc=100
            }
            else if(document.getElementById('Discount').value<0){
                disc=0
            }
            else{
                disc=document.getElementById('Discount').value
            }
            
        }
        if(document.getElementById('Received_Amount').value.length!==0){
            recamt=document.getElementById('Received_Amount').value
        }
        const action=ActionCreator('change',[recamt,disc])
        store.dispatch(action);
    }

    return(
        <div>
            {arr.map((ele,index)=>{
                if(ele==='Discount'){
                    return(
                        <div key={index} className='d-flex flex-row'>
                            <div >
                                <h3 key={index}>{ele} : &nbsp;</h3>
                            </div>
                            <div>
                                <input key={ele} id={ele} type='number' onChange={entered} className="form-control bg-white"/>
                            </div>
                        </div>
                    )
                }
                if(ele==='Received_Amount'){
                    return(
                        <div key={index} className='d-flex flex-row'>
                            <div>
                                <h3 key={index}>{ele} : &nbsp;</h3>
                            </div> 
                            <div>
                                <input id={ele} type='number' onChange={entered} className="form-control bg-white"/>
                            </div>
                        </div>
                    )
                }
                else{
                    return(
                        <h3 key={index}>{ele} : {output[ele]}</h3>
                    )
                }
            })}
        </div>
    )
}