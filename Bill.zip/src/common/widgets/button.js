export const PButton=({title,fn,classN})=>{
    function callback(){
        fn();
    }
    return(
        <div>
            <button type="button" className={classN} onClick={callback}>{title}</button>
        </div>
    )
}