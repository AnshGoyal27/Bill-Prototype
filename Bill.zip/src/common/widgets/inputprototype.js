export const InputModel=({title,ph,type,classN,use='enabled'})=>{
    if(classN==='btn btn-outline-secondary'){
        let choice=[];
        if(title==='Payment'){
            choice=process.env.REACT_APP_PAYMENT_TYPE.split(",");
        }
        else if(title==='Tax'){
            let obj= JSON.parse(process.env.REACT_APP_TAX);
            for(let i in obj){
                choice.push(i);
            }
        }
        else if(title==='Item_Name'){
            let obj= JSON.parse(process.env.REACT_APP_ITEM_NAME);
            for(let i in obj){
                choice.push(i);
            }
        }
        return(
            <div className="input-group mb-3">
                <label className="input-group-text" htmlFor={title}>{title}</label>
                <select className="form-select" id={title}>
                    {choice.map((ele,index)=>(<option key={index} value={ele}>{ele}</option>))}
                </select>
            </div>
        )
    }
    else{
        if(use==='disabled'){
            return(
                <div className="input-group mb-3">
                    <span className={classN}>{title}</span>
                    <input id={title} type={type} className="form-control bg-white" placeholder={ph} aria-label={ph} aria-describedby={title} disabled/>
                </div>
            )
        }
        else{
            return(
                <div className="input-group mb-3">
                    <span className={classN} >{title}</span>
                    <input type={type} id={title} className="form-control" placeholder={ph} aria-label={ph} aria-describedby={title}/>
                </div>
            )
        }
        
    }
    
}