
export const reducerfn=(state={
    Customer:{
        Order_ID:0,
        Name:'',
        Payment:'',
        Mobile_No:0,
        Date:'',
        Tax:0
    },
    ItemStore:[],
    Data:{
        Sub_Total:0,
        Total_Tax:0,
        Total_Amount:0,
        Discount:0,
        Net_Amount:0,
        Received_Amount:0,
        Return_Amount:0
    },
    Disc:0,
    RecAmt:0,
    Delete:[],
    ID:0
},action)=>{

    function dataedit(arr){
        let obj={
            Sub_Total:0,
            Total_Tax:0,
            Total_Amount:0,
            Discount:0,
            Net_Amount:0,
            Received_Amount:0,
            Return_Amount:0
        };
        if(arr.length===0){
            return obj;
        }
        else{
            arr.forEach(ele=>{
              obj.Sub_Total+=ele.Amount; 
              obj.Total_Tax+=ele.Tax;
              obj.Total_Amount+=ele.Total
            })
            obj.Discount=((state.Disc)/100)*(obj.Total_Amount);
            obj.Net_Amount=(obj.Total_Amount)-(obj.Discount);
            obj.Return_Amount=(obj.Net_Amount)-(state.RecAmt);
        }
        
        return obj;
    }

    if(action.type==='set'){
        if(state.ItemStore.length>0){
            state.ItemStore.forEach(ele=>{
                ele.Tax=(ele.Amount)*(ele.Quantity)*(action.payload.Tax);
                ele.Total=(ele.Amount)+(ele.Tax);
            })
        }
        const newdata=dataedit(state.ItemStore);
        return {...state,Customer:action.payload,Data:newdata};
    }
    else if(action.type==='add'){
        let ItemN=state.ItemStore;
        ItemN.push(action.payload)
        const newdata=dataedit(ItemN);
        return {...state,ItemStore:ItemN,Data:newdata,ID:state.ID+1};
    }
    else if(action.type==='new'){
        const custom={
            Order_ID:0,
            Name:'',
            Payment:'',
            Mobile_No:0,
            Date:'',
            Tax:0
        }
        const newdata=dataedit([]);
        return{...state,Customer:custom,ItemStore:[],Data:newdata,ID:0};
    }
    else if(action.type==='change'){
        state.Disc=action.payload[1]
        state.RecAmt=action.payload[0];
        const newdata=dataedit(state.ItemStore);
        return {...state,Data:newdata};
        
    }
    else if(action.type==='dellist'){
        if(state.Delete.includes(action.payload)){
            return {state}
        }
        else{
            let arr=state.Delete;
            arr.push(action.payload)
            return {...state,Delete:arr};
        }
    }
    else if(action.type==='delete'){
        if(state.Delete.length===0){
            window.alert('Click row to Select');
        }
        else{
            let arr=[]
            state.ItemStore.forEach((ele)=>{
                if(!state.Delete.includes(ele.ID)){
                    arr.push(ele);
                }
            })
            const newdata=dataedit(arr);
            return{...state,ItemStore:arr,Delete:[],Data:newdata}
        }
    }
    else if(action.type==='ndellist'){
        let arr=[]
        state.Delete.forEach((ele)=>{
            if(!ele===action.payload){
                arr.push(ele)
            }
        })
        return{...state,Delete:arr}
    }

    return state;
}