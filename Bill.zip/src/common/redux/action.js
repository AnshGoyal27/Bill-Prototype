export const ActionCreator = (type , data)=>{
    return {
        type: type,
        payload: data
    }
}