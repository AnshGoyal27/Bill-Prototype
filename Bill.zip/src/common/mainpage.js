import { PData } from "../calculator/data";
import { PHeader } from "../header/header"
import { Iteminput } from "../Items/iteminput"
import { TableP } from "../table/tableprototype";

export const PDisplay=()=>{



 return(
    <div>
        <PHeader/>
        <Iteminput/>
        <TableP/>
        <PData/>
    </div>
 )   
}