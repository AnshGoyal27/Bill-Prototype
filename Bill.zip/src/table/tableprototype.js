import { useSelector } from "react-redux";
import { ActionCreator } from "../common/redux/action";
import { store } from "../common/redux/store";

export const TableP=()=>{
    
    const TableC=process.env.REACT_APP_TABLEHEAD.split(",");

    const data=(useSelector(state=>state));
    console.log(data);

    function rowselected(index){
        if(data.Delete.includes(index)){
            document.getElementById(index).removeAttribute('style');
            const action=ActionCreator('ndellist',index);
            store.dispatch(action);
        }
        else{
            document.getElementById(index).style.backgroundColor='red';
            const action=ActionCreator('dellist',index);
            store.dispatch(action);
        }
        
        
    }
    

    return(
    <table className="table table-bordered table-hover table-striped">
        <thead className="table-dark">
            <tr>
                {TableC.map((ele,index)=><th key={index} scope="col">{ele}</th>)}
            </tr>
        </thead>
        <tbody>
            {data.ItemStore.map((ele,index)=>{
                return(
                    <tr key={index} id={ele.ID} onClick={()=>rowselected(ele.ID)}>
                        <th scope="row" >{ele.ItemCode}</th>
                        <td>{ele.ItemName}</td>
                        <td>{ele.Quantity}</td>
                        <td>{ele.Rate}</td>
                        <td>{ele.Amount}</td>
                        <td>{ele.Tax}</td>
                        <td>{ele.Total}</td>
                    </tr>
                )
            })}
        </tbody>
    </table>
    )
}