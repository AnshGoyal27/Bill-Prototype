import { useState } from "react";
import { ActionCreator } from "../common/redux/action";
import { store } from "../common/redux/store";
import { PButton } from "../common/widgets/button";
import { InputModel } from "../common/widgets/inputprototype"

export const PHeader=()=>{
    
    let obj1= JSON.parse(process.env.REACT_APP_TAX);
    for(let i in obj1){
        obj1[i]=parseFloat(obj1[i]);
    }

    const [counter,SetCounter]=useState(0);
    const CompanyName=process.env.REACT_APP_COMPANY_NAME + ' Billing System'
    const ConsumerKey=process.env.REACT_APP_CUSTOMER.split(",");
    
    function set(){
        let obj={}
        ConsumerKey.forEach(ele=>{
            let element=document.getElementById(ele);
            element.disabled=true;
            if(element.value.length===0){
                if (element.type==='number'){
                    element.value=0;
                }
                else if(element.type==='text'){
                    element.value='default';
                }
                else{
                    element.value="2022-09-09T18:10";
                }
            }
            if(ele==='Order_ID'){
                obj[ele]=counter;
            }
            if(ele==='Tax'){
                obj[ele]=obj1[element.value];
            }
            else{
                obj[ele]=element.value;
            }
        })
        const action=ActionCreator('set',obj);
        store.dispatch(action);
    }
    function update(){
        ConsumerKey.forEach(ele=>{
            let element=document.getElementById(ele);
            if(ele!=='Order_ID'){
                element.disabled=false;
            }
            
        })
    }

    function news(){
        SetCounter(counter+1);
        ConsumerKey.forEach(ele=>{
            if(ele==='Order_ID'){
                document.getElementById(ele).value=counter+1;
            }
            else if(ele==='Tax'){
                document.getElementById(ele).value='CGST';
                document.getElementById(ele).disabled=false;
            }
            else{
                document.getElementById(ele).value='';
                document.getElementById(ele).disabled=false;
            }
        })
        const action=ActionCreator('new');
        store.dispatch(action);
    }
    
    return(
        <div>
            <h1 align="center" className="p-3 mb-2 bg-primary text-white">{CompanyName}</h1>
            <div className="p-3 mb-2 bg-light text-dark">
                <div>
                    <InputModel title='Order_ID' ph={counter} type='number' classN='input-group-text' use='disabled'/>
                    <InputModel title='Name' ph='Enter your Name' type='text' classN='input-group-text'/>
                    <InputModel title='Payment' ph='Select Payment Type' type='text' classN='btn btn-outline-secondary'/>
                    <InputModel title='Mobile_No' ph='Enter your Mobile Number' type='number' classN='input-group-text'/>
                    <InputModel title='Date' ph='Enter your Date' type='datetime-local' classN='input-group-text'/>
                    <InputModel title='Tax' ph='Select Tax Type' type='text' classN='btn btn-outline-secondary'/>
                </div>
                <div className="btn-group">
                    <PButton title='Set' classN='btn btn-success' fn={set}/> &nbsp;
                    <PButton title='Update' classN='btn btn-warning' fn={update}/> &nbsp;
                    <PButton title='New' classN='btn btn-danger' fn={news}/>
                </div>
            </div>`
        </div>
    )
}