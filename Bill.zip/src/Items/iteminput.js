import { useSelector } from "react-redux";
import { ActionCreator } from "../common/redux/action";
import { store } from "../common/redux/store";
import { PButton } from "../common/widgets/button"
import { InputModel } from "../common/widgets/inputprototype"

export const Iteminput=()=>{

    const TAX=useSelector(state=>state.Customer.Tax);
    const DeleteRow=useSelector(state=>state.Delete);
    const id=useSelector(state=>state.ID);

    let obj= JSON.parse(process.env.REACT_APP_ITEM_NAME);
    for(let i in obj){
        obj[i]=obj[i].split(",")
        let arr=[]
        for(let j of obj[i]){
            arr.push(parseInt(j));
        }
        obj[i]=arr;
    }
    

    function add(){
        let Name=document.getElementById('Item_Name').value;
        let Quantities=document.getElementById('Quantity').value;
        if(document.getElementById('Quantity').value.length===0){
            Quantities=1;
        }
        const action=ActionCreator('add',{
                ID:id+1,
                ItemCode:obj[Name][0],
                ItemName:Name,
                Quantity:Quantities,
                Rate:obj[Name][1],
                Amount:obj[Name][1] * Quantities,
                Tax:obj[Name][1] * Quantities * TAX,
                Total:(obj[Name][1] * Quantities)+ (obj[Name][1] * Quantities * TAX)
            })
        store.dispatch(action);
    }

    function deleted(){
        if(DeleteRow.length>0){
            DeleteRow.forEach(ele=>{
                document.getElementById(ele).removeAttribute('style');
            })
        }
        const action=ActionCreator('delete');
        store.dispatch(action);
    }

    return(
        <div className="p-3 mb-2 bg-light text-dark">
            <div className="row g-3">
                <div className="col-md-6">
                    <InputModel title='Item_Name' type='text' classN='btn btn-outline-secondary'/>
                </div>
                <div className="col-md-6">
                    <InputModel title='Quantity' ph='Enter No.' type='number' classN='input-group-text'/>
                </div>
            </div>
            <div className="btn-group">
                <PButton classN='btn btn-success' fn={add} title='Add'/> &nbsp;
                <PButton classN='btn btn-danger' fn={deleted} title='Delete'/>
            </div>
        </div>
    )
}



/*
for(let i in obj){
                let arr=obj[i].split(",");
                arr[0]=parseInt(arr[0]);
                arr[1]=parseInt(arr[1]);
                obj[i]=arr;
            }
*/