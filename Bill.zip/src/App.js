import './App.css';
import { PDisplay } from './common/mainpage';

function App() {
  return (
    <div>
      <PDisplay/>
    </div>
  );
}

export default App;
